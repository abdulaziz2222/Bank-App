package com.example.bankapplication;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Date;
import java.sql.SQLData;

public class MainActivity extends AppCompatActivity {
    private static final int MY_PERMISSIONS_RECEIVE_SMS = 0;
    static BankDataBase db;
    Button ex_btn;
    Button in_btn;
    TextView baTv;
    Receiver myReceiver = new Receiver(){
        @Override
        public void onReceive(Context context, Intent intent) {
            super.onReceive(context, intent);
            if(phone_number.equals("0562959883")){
                if(themessage.contains("شراء")||themessage.contains("سداد")||themessage.contains("مشتريات")){
                   db.addProces("expenses",amount,date2);
                    Toast.makeText(context, db.loadFromDataBase(), Toast.LENGTH_SHORT).show();
                }else if (themessage.contains(("حوالة واردة"))
                    ||themessage.contains("ايداع")||themessage.contains("استرداد")){
                   db.addProces("incomes",amount,date2);
            }}

        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(myReceiver,new IntentFilter("android.provider.Telephony.SMS_RECEIVED"));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(myReceiver);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        baTv =findViewById(R.id.balance_nbr);
        db=new BankDataBase(this,null);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED) {
            if(ActivityCompat.shouldShowRequestPermissionRationale(this,Manifest.permission.RECEIVE_SMS))
            {
                //رفض اليوسر الموافقه
            }else
            {
                ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.RECEIVE_SMS},MY_PERMISSIONS_RECEIVE_SMS);
            }
        }
        ex_btn=findViewById(R.id.expenses_btn);
        ex_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                   Intent intent = new Intent(MainActivity.this,Inomes_barchart.class);
                   intent.putExtra("key","expenses");
                   startActivity(intent);
            }
        });
        in_btn=findViewById(R.id.incomes_btn);
        in_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this,Inomes_barchart.class);
                intent.putExtra("key","incomes");
                startActivity(intent);
            }
        });
        String q=String.valueOf(db.balance());
        baTv.setText(q);

    }
    @Override
    public void onRequestPermissionsResult(int requestCode,String Permissions[],int[] grantResults){
        super.onRequestPermissionsResult(requestCode, Permissions, grantResults);

        switch (requestCode){
            case MY_PERMISSIONS_RECEIVE_SMS:
                if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED)
                {
                    Toast.makeText(this, "THANKS", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(this, "I can't work without the permission", Toast.LENGTH_SHORT).show();
                }
        }
    }
}