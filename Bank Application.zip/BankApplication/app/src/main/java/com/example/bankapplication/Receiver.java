package com.example.bankapplication;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.icu.text.SimpleDateFormat;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.telephony.SmsMessage;
import android.widget.Toast;
import java.util.Date;

public class Receiver extends BroadcastReceiver {
 String themessage,phone_number;
 String type,date2;
double amount;
Date date,t;    @Override
    public void onReceive(Context context, Intent intent) {
        Bundle bundle =intent.getExtras();

        if(bundle!=null)
        {
            Object []mypdus = (Object[]) bundle.get("pdus");
            SmsMessage []message =new SmsMessage[mypdus.length];
            for (int i =0 ;i<mypdus.length;i++){
                message[i]=message[i].createFromPdu((byte[]) mypdus[i]);
                themessage=message[i].getMessageBody();
                phone_number=message[i].getOriginatingAddress();
            }
            if(phone_number.equals("0562959883")){
            String []lins = themessage.split(System.lineSeparator());
               if(themessage.contains("شراء")||themessage.contains("سداد")||themessage.contains("مشتريات"))
               {//expenses and his incomes
                type="expenses";
                amount = Double.parseDouble(lins[1]);
                date= new Date();
                date2=date.toString();
               }
               else if (themessage.contains(("حوالة واردة"))
                       ||themessage.contains("ايداع")||themessage.contains("استرداد")){
                   type="incomes";
                   amount = Double.parseDouble(lins[1]);
                   date= new Date();
                   date2=date.toString();
               }
            }
        }
        
    }

}
