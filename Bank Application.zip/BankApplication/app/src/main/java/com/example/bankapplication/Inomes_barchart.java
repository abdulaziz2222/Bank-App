package com.example.bankapplication;

import static com.example.bankapplication.MainActivity.db;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;
import java.util.Date;

public class Inomes_barchart extends AppCompatActivity {

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inomes_barchart);
        BarChart barChart =findViewById(R.id.per_day);

        String type=getIntent().getStringExtra("key");
        double a=0,b=0,c=0,d=0,e=0,f=0,g=0;
        Date d1 =new Date();
        a=db.countPerDay(d1.toString(),0,type);
        b=db.countPerDay(d1.toString(),1,type);
        c=db.countPerDay(d1.toString(),2,type);
        d=db.countPerDay(d1.toString(),3,type);
        e=db.countPerDay(d1.toString(),4,type);
        f=db.countPerDay(d1.toString(),5,type);
        g=db.countPerDay(d1.toString(),6,type);

        ArrayList<BarEntry> visitors = new ArrayList<>();
        visitors.add(new BarEntry(1, (float) a));
        visitors.add(new BarEntry(2,(float)b));
        visitors.add(new BarEntry(3,(float)c));
        visitors.add(new BarEntry(4,(float)d));
        visitors.add(new BarEntry(5,(float)e));
        visitors.add(new BarEntry(6,(float)f));
        visitors.add(new BarEntry(7,(float)g));

        BarDataSet barDataSet =new BarDataSet(visitors,"Visitors");
        barDataSet.setColors(ColorTemplate.MATERIAL_COLORS);
        barDataSet.setValueTextColor(Color.BLACK);
        barDataSet.setValueTextSize(16f);

        BarData barData = new BarData((barDataSet));

        barChart.setFitBars(true);
        barChart.setData(barData);
        barChart.getDescription().setText("last 7 days Chart");
        barChart.animate();
        //_______________________________________________________________________//
        BarChart barChart2 =findViewById(R.id.per_month);

        String type2=getIntent().getStringExtra("key");
        double a1=0,b1=0,c1=0,d2=0,e1=0,f1=0,g1=0,h=0,i=0,j=0,k=0,l=0;
        a1=db.countpermounth(d1.toString(),0,type);
        b1=db.countpermounth(d1.toString(),1,type);
        c1=db.countpermounth(d1.toString(),2,type);
        d2=db.countpermounth(d1.toString(),3,type);
        e1=db.countpermounth(d1.toString(),4,type);
        f1=db.countpermounth(d1.toString(),5,type);
        g1=db.countpermounth(d1.toString(),6,type);
        h =db.countpermounth(d1.toString(),7,type);
        i =db.countpermounth(d1.toString(),8,type);
        j =db.countpermounth(d1.toString(),9,type);
        k =db.countpermounth(d1.toString(),10,type);
        l =db.countpermounth(d1.toString(),11,type);

        ArrayList<BarEntry> visitor1s = new ArrayList<>();
        visitor1s.add(new BarEntry(1, (float) a1));
        visitor1s.add(new BarEntry(2,(float)b1));
        visitor1s.add(new BarEntry(3,(float)c1));
        visitor1s.add(new BarEntry(4,(float)d2));
        visitor1s.add(new BarEntry(5,(float)e1));
        visitor1s.add(new BarEntry(6,(float)f1));
        visitor1s.add(new BarEntry(7,(float)g1));
        visitor1s.add(new BarEntry(8,(float)h));
        visitor1s.add(new BarEntry(9,(float)i));
        visitor1s.add(new BarEntry(10,(float)j));
        visitor1s.add(new BarEntry(11,(float)k));
        visitor1s.add(new BarEntry(12,(float)l));

        BarDataSet barDataS2et =new BarDataSet(visitor1s,"Visitors");
        barDataS2et.setColors(ColorTemplate.MATERIAL_COLORS);
        barDataS2et.setValueTextColor(Color.BLACK);
        barDataS2et.setValueTextSize(16f);

        BarData barD2ata = new BarData((barDataS2et));

        barChart2.setFitBars(true);
        barChart2.setData(barD2ata);
        barChart2.getDescription().setText("last 12 month Chart");
        barChart2.animate();
    }
}