package com.example.bankapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.icu.text.SimpleDateFormat;
import android.os.Build;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

public class BankDataBase extends SQLiteOpenHelper {
    public static final String BANK_DATABASE_NAME="BanDataBase";
    public static final int VERSION =1;

    public static final String TABLE_NAME="BankTable";

    public static final String PROCES_ID="ProcesId";
    public static final String PROCES_TYPE="ProcesType";
    public static final String PROCES_VALUE="ProcesValue";
    public static final String PROCES_DATE="ProcesDate";

    public BankDataBase(@Nullable Context context,  SQLiteDatabase.CursorFactory factory) {
        super(context, BANK_DATABASE_NAME, factory, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
      db.execSQL("CREATE TABLE "+TABLE_NAME+"("+PROCES_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "
              +PROCES_TYPE+" TEXT, "+PROCES_VALUE
              +" REAL, "+PROCES_DATE+" TEXT)");
    }

   @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public void addProces(String type, double value, String date){
        SQLiteDatabase db =getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(PROCES_VALUE,value);
        cv.put(PROCES_TYPE,type);
        cv.put(PROCES_DATE,date);
        db.insert(TABLE_NAME,null,cv);
        db.close();
    }
    public String loadFromDataBase(){
        SQLiteDatabase db =getWritableDatabase();
        String query = "Select * FROM "+TABLE_NAME;
        Cursor cursor =db.rawQuery(query,null);
        String res ="";
        while (cursor.moveToNext()){
            res+=cursor.getString(0)+" "+
                    String.valueOf(cursor.getString(1)+" ,"+
                    cursor.getString(2)+" ,"
                    +cursor.getString(3));
        }
        db.close();
        cursor.close();
        return res;
    }
    @RequiresApi(api = Build.VERSION_CODES.N)
    public double countPerDay(String Sdate, int nb, String type){
        SQLiteDatabase db =getWritableDatabase();
        String query = "Select * FROM "+TABLE_NAME;
        Cursor cursor =db.rawQuery(query,null);
        double res =0.0;
        String d;
        Date date2;
        Date date= new Date(Sdate);
        while (cursor.moveToNext()){
            d = cursor.getString(3);
            date2 =new Date(d);
            try {
                date = new SimpleDateFormat("yy-MM-dd hh:mm", Locale.getDefault()).parse(Sdate);
                date2 = new SimpleDateFormat("yy-MM-dd hh:mm", Locale.getDefault()).parse(d);
            }  catch (ParseException e){
            System.out.println(e);
            }
            Calendar cal = Calendar.getInstance();
            Calendar cal2 = Calendar.getInstance();
            cal.setTime(date);
            cal2.setTime(date2);
            if (cursor.getString(1).equals(type)) {
                if (cal.get(Calendar.DAY_OF_YEAR)-nb== cal2.get(Calendar.DAY_OF_YEAR)
                        &&cal.get(Calendar.YEAR)==cal2.get(Calendar.YEAR)) {
                    res = res + Double.parseDouble(cursor.getString(2));
                }
            }
        }

        db.close();
        cursor.close();
        return res;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public double countpermounth(String Sdate,int nb,String type){
        SQLiteDatabase db =getWritableDatabase();
        String query = "Select * FROM "+TABLE_NAME;
        Cursor cursor =db.rawQuery(query,null);
        double res =0.0;
        String d;
        Date date2;
        Date date= new Date(Sdate);
        while (cursor.moveToNext()){
            d = cursor.getString(3);
            date2 =new Date(d);
            try {
                date = new SimpleDateFormat("yy-MM-dd hh:mm", Locale.getDefault()).parse(Sdate);
                date2 = new SimpleDateFormat("yy-MM-dd hh:mm", Locale.getDefault()).parse(d);
            }  catch (ParseException e){
                System.out.println(e);
            }
            Calendar cal = Calendar.getInstance();
            Calendar cal2 = Calendar.getInstance();
            cal.setTime(date);
            cal2.setTime(date2);
          //  return cal2.get(Calendar.MONTH);
            if (cursor.getString(1).equals(type)) {
                if (cal.get(Calendar.MONTH)-nb== cal2.get(Calendar.MONTH)
                        &&cal.get(Calendar.YEAR)==cal2.get(Calendar.YEAR)) {
                    res = res + Double.parseDouble(cursor.getString(2));
                }
            }
        }

        db.close();
        cursor.close();
        return res;
    }
    public double balance(){
        SQLiteDatabase db =getWritableDatabase();
        String query = "Select * FROM "+TABLE_NAME;
        Cursor cursor =db.rawQuery(query,null);
        double res =0.0;
        while (cursor.moveToNext()){
            if(cursor.getString(1).equals("incomes")){
            res=res+Double.parseDouble(cursor.getString(2));
            }else{res=res-Double.parseDouble(cursor.getString(2));}
        }//                      cursor.getString(3));
        db.close();
        cursor.close();
        return res;
    }

}
